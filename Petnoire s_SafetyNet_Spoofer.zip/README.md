## PetNoire's SafetySpoofer
[More details in support thread](https://forum.xda-developers.com/editpost.php?do=updatepost&postid=77579853)  
Fix SafetyNet on devices with MIUI Developer/Beta ROM, CyanogenMod, Lineage OS, Resurrection Remix, etc.

## Changelog
#### v1
- Initial release
- Took universal-safetynet-spoofer, then took most of it out again. all thats left is the props config
